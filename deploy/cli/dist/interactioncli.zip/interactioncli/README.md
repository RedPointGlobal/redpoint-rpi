# Interaction CLI

Command-line tool for deploying and managing Redpoint Interaction (RPI) on Kubernetes.

## Prerequisites

- bash
- helm (v3+)
- kubectl (configured with cluster access)
- python3 with PyYAML (`pip3 install pyyaml`)

## Quick Start

1. Generate your overrides file using the Web UI at https://rpi-helm-assistant.redpointcdp.com
2. Generate secrets from your overrides:

       bash interactioncli.sh secrets -f overrides.yaml

3. Deploy to your cluster:

       bash interactioncli.sh deploy -f overrides.yaml -c /path/to/chart

## Commands

    bash interactioncli.sh                              # Full interactive setup
    bash interactioncli.sh secrets -f overrides.yaml    # Generate secrets.yaml
    bash interactioncli.sh deploy -f overrides.yaml     # Deploy to cluster
    bash interactioncli.sh deploy -f overrides.yaml --dry-run  # Preview manifests
    bash interactioncli.sh status -n my-namespace       # Check deployment status
    bash interactioncli.sh troubleshoot -n my-namespace # Diagnose issues
    bash interactioncli.sh -a autoscaling               # Add a feature

## Workflow

    Web UI (generate overrides) -> CLI secrets -> CLI deploy

For full documentation, visit: https://rpi-helm-assistant.redpointcdp.com
